#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

int led = 13;
int btn = 7;

int x = 0;
int prev_btn_data = HIGH;

// Função matemática
int funcao(int x)
{
  return x * x + 2 * x + 1;
}

void setup()
{
  lcd.init();
  lcd.backlight();

  pinMode(led, OUTPUT);
  pinMode(btn, INPUT_PULLUP);
}

void loop()
{
  int btn_data = digitalRead(btn);

  // Quando apertar o botão
  if (btn_data == LOW && prev_btn_data == HIGH)
  {
    x++;

    int resultado = funcao(x);

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("x = ");
    lcd.print(x);

    lcd.setCursor(0, 1);
    lcd.print("f(x) = ");
    lcd.print(resultado);

    digitalWrite(led, !digitalRead(led));

    delay(200);
  }

  prev_btn_data = btn_data;
}