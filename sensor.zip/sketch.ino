#define pin_TRIGGER 4
#define pin_ECHO 2
#define pin_BUZZER 3

void setup() {
  Serial.begin(9600);
  pinMode(pin_TRIGGER, OUTPUT);
  pinMode(pin_ECHO, INPUT);
  pinMode(pin_BUZZER, OUTPUT);
}

void loop() {
  long duration, range;
  
  // Ultrasonic trigger pulse
  digitalWrite(pin_TRIGGER, LOW);
  delayMicroseconds(2); 
  digitalWrite(pin_TRIGGER, HIGH);
  delayMicroseconds(10); 
  digitalWrite(pin_TRIGGER, LOW);

  // Read echo duration and calculate distance
  duration = pulseIn(pin_ECHO, HIGH);
  range = (duration / 2) / 29;

  // ZONE 1: Out of reach (greater than 200 or error)
  if (range >= 200 || range <= 0) {
    Serial.println("Get Closer :3");
    delay(500); // A chill delay so it doesn't spam the monitor too fast
  } 
  
  // ZONE 2: 50cm or closer! 
  else if (range <= 50) {
    Serial.print(range);
    Serial.println("cm - TOO CLOSE! >∆<");
    
    // Fast, urgent beeping
    tone(pin_BUZZER, 1000, 50); 
    delay(100); 
  } 
  
  // ZONE 3: Normal range (51cm up to 199cm)
  else {
    Serial.print(range);
    Serial.println("cm");
    
    // Dynamic beeping based on distance
    tone(pin_BUZZER, 1000, 30); 
    int beepInterval = range * 5; 
    delay(beepInterval);
  }
}